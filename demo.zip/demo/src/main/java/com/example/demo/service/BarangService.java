package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Barang;
import com.example.demo.repository.BarangRepository;

@Service
public class BarangService {
    @Autowired
    private BarangRepository barangRepository;

    public List<Barang> getAllBarang() { 
        return barangRepository.findAll(); 
    }

    public Barang addBarang(Barang obj){
        obj.setPesananID(null);
        return barangRepository.save(obj);
    }
    
    public Barang getBarangById(Long id) { 
        return barangRepository.findById(id).orElse(null); 
    }

    public void saveBarang(Barang barang) { 
        barangRepository.save(barang); 
    }

    public Barang updateBarang(long id, Barang obj){
        return barangRepository.save(obj);
    }

    public void deleteBarang(Long id) { 
        barangRepository.deleteById(id); 
    }
}