package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.entity.Orang;
import com.example.demo.entity.Pelanggan;
import com.example.demo.entity.detailPemesanan;
import com.example.demo.service.DetailPemesananService;
import com.example.demo.service.OrangService;
import com.example.demo.service.PelangganService;

import jakarta.servlet.http.HttpServletRequest;


@Controller
public class EkspedisiController {
    @Autowired
    private DetailPemesananService detailPemesananService;
    @Autowired
    private OrangService orangService;
    @Autowired
    private PelangganService pelangganService;

    // MENU
    @GetMapping(value={"/menu", "/menu/"})
    public String MenuPage(Model model) {
        return "menu.html";
    }


    // BARANG

    @GetMapping(value={"/orang", "/orang/"})
    public String BarangPage(Model model) {
        List<Orang> orangList = orangService.getAllOrang();
        model.addAttribute("orangList", orangList);
        model.addAttribute("orangInfo", new Orang());
        return "orang.html";
    }

    @GetMapping("/orang/{id}")
    public String produkGetRec(Model model, @PathVariable("id") int id){
    List<Orang> orangList = orangService.getAllOrang();
    Orang orangRec = orangService.getOrangById(id);
    model.addAttribute("orangList", orangList);
    model.addAttribute("orangRec", orangRec);
    return "orang.html";
    }

    @PostMapping( value={"/orang/submit/", "/orang/submit/{id}"}, params={"add"})
    public String orangAdd(@ModelAttribute("orangInfo") Orang orangInfo){
        orangService.addOrang(orangInfo);
        return "redirect:/orang";
    }

    @PostMapping( value="/orang/submit/{id}", params={"edit"})
    public String orangEdit(@ModelAttribute("orangInfo") Orang orangInfo,
    @PathVariable("id") int id){
        orangService.updateOrang(id, orangInfo);
        return "redirect:/orang";
    }

    @PostMapping( value="/orang/submit/{id}", params={"delete"})
    public String orangDelete(@PathVariable("id") int id){
        orangService.deleteOrang(id);
        return "redirect:/orang";
    }

    // DetailPemesanan

    @GetMapping(value={"/detail", "/detail/"})
    public String DetailPage(Model model) {
        List<detailPemesanan> detailList = detailPemesananService.getAllDetailPemesanan();
        model.addAttribute("detailList", detailList);
        model.addAttribute("detailInfo", new detailPemesanan());
        return "detail.html";
    }

    @GetMapping("/detail/{id}")
    public String detailGetRec(Model model, @PathVariable("id") int id){
        List<detailPemesanan> detailList = detailPemesananService.getAllDetailPemesanan();
        detailPemesanan detailRec = detailPemesananService.getDetailPemesananById(id);
        model.addAttribute("detailList", detailList);
        model.addAttribute("detailRec", detailRec);
        return "detail.html";
    }

    @PostMapping( value={"/detail/submit/", "/detail/submit/{id}"}, params={"add"})
    public String detailAdd(@ModelAttribute("orangInfo") detailPemesanan detailInfo){
        detailPemesananService.addDetailPemesanan(detailInfo);
        return "redirect:/detail";
    }

    @PostMapping( value="/detail/submit/{id}", params={"edit"})
    public String detailEdit(@ModelAttribute("detailInfo") detailPemesanan detailInfo,
    @PathVariable("id") int id){
        detailPemesananService.updateDetailPemesanan(id, detailInfo);
        return "redirect:/detail";
    }

    @PostMapping( value="/detail/submit/{id}", params={"delete"})
    public String detailDelete(@PathVariable("id") int id){
        detailPemesananService.deleteDetailPemesanan(id);
        return "redirect:/detail";
    }

    // Pelanggan

    @GetMapping(value="/login")
    public String pelangganLoginPage(Model model, HttpServletRequest request) {
    if(request.getSession().getAttribute("Pelanggan") != null){
        return "redirect:/pelanggan";
    }
        else return "loginpelanggan";
    }

    @PostMapping(value="/validateLogin")
    public String pelangganLogin(Model model, @RequestParam(value="AccountID") Integer kodeUser,
    @RequestParam(value="noTelp") String passUser, HttpServletRequest request) {
        Pelanggan P = pelangganService.findPelanggan(kodeUser);
        model.addAttribute("userRec", P);
            if(P != null && passUser.equals(P.getNoTelp())) {
            request.getSession().setAttribute("Pelanggan", P);
            model.addAttribute("userRec", P);
            return "redirect:/pelanggan";
        }
        else return "redirect:/login";
    }

    @GetMapping(value="/pelangganlogout")
    public String pelangganlogout(HttpServletRequest request) {
    if (request.getSession().getAttribute("Pelanggan") != null) {
        request.getSession().invalidate();
    }
        return "redirect:/login";
    }

    @GetMapping(value={"/pelanggan", "/pelanggan/"})
    public String PelangganPage(Model model, HttpServletRequest request) {
        if(request.getSession().getAttribute("Pelanggan") != null){
            List<Pelanggan> pelangganList = pelangganService.getAllPelanggan();
            model.addAttribute("pelangganList", pelangganList);
            model.addAttribute("pelangganInfo", new Pelanggan());
            model.addAttribute("logPelanggan", request.getSession().getAttribute("Pelanggan"));
            return "pelanggan.html";
        }
        else return "redirect:/login";
    }

    @GetMapping("/pelanggan/{id}")
    public String pelangganGetRec(Model model, @PathVariable("id") int id){
        List<Pelanggan> pelangganList = pelangganService.getAllPelanggan();
        Pelanggan pelangganRec = pelangganService.getPelangganById(id);
        model.addAttribute("pelangganList", pelangganList);
        model.addAttribute("pelangganRec", pelangganRec);
        return "pelanggan.html";
    }

    @PostMapping( value={"/pelanggan/submit/", "/pelanggan/submit/{id}"}, params={"add"})
    public String pelangganAdd(@ModelAttribute("pelangganInfo") Pelanggan pelangganInfo){
        pelangganService.addPelanggan(pelangganInfo);
        return "redirect:/pelanggan";
    }

    @PostMapping( value="/pelanggan/submit/{id}", params={"edit"})
    public String pelangganEdit(@ModelAttribute("pelangganInfo") Pelanggan pelangganInfo,
    @PathVariable("id") int id){
        pelangganService.updatePelanggan(id, pelangganInfo);
        return "redirect:/pelanggan";
    }

    @PostMapping( value="/pelanggan/submit/{id}", params={"delete"})
    public String pelangganDelete(@PathVariable("id") int id){
        pelangganService.deletePelanggan(id);
        return "redirect:/pelanggan";
    }

}