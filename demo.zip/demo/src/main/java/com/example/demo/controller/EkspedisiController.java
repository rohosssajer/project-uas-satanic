package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.entity.Barang;
import com.example.demo.entity.Orang;
import com.example.demo.entity.Pelanggan;
import com.example.demo.entity.Pengiriman;
import com.example.demo.entity.detailPemesanan;
import com.example.demo.service.BarangService;
import com.example.demo.service.DetailPemesananService;
import com.example.demo.service.OrangService;
import com.example.demo.service.PelangganService;
import com.example.demo.service.PengirimanService;

import jakarta.servlet.http.HttpServletRequest;


@Controller
public class EkspedisiController {
    @Autowired
    private DetailPemesananService detailPemesananService;
    @Autowired
    private OrangService orangService;
    @Autowired
    private PelangganService pelangganService;
    @Autowired
    private BarangService barangService;
    @Autowired
    private PengirimanService pengirimanService;

    // MENU
    @GetMapping(value={"/menu", "/menu/"})
    public String MenuPage(Model model) {
        return "menu.html";
    }


    // Orang

    @GetMapping(value={"/orang", "/orang/"})
    public String OrangPage(Model model) {
        List<Orang> orangList = orangService.getAllOrang();
        model.addAttribute("orangList", orangList);
        model.addAttribute("orangInfo", new Orang());
        return "orang.html";
    }

    @GetMapping("/orang/{id}")
    public String orangGetRec(Model model, @PathVariable("id") int id){
    List<Orang> orangList = orangService.getAllOrang();
    Orang orangRec = orangService.getOrangById(id);
    model.addAttribute("orangList", orangList);
    model.addAttribute("orangRec", orangRec);
    return "orang.html";
    }

    @PostMapping( value={"/orang/submit/", "/orang/submit/{id}"}, params={"add"})
    public String orangAdd(@ModelAttribute("orangInfo") Orang orangInfo){
        orangService.addOrang(orangInfo);
        return "redirect:/orang";
    }

    @PostMapping( value="/orang/submit/{id}", params={"edit"})
    public String orangEdit(@ModelAttribute("orangInfo") Orang orangInfo,
    @PathVariable("id") int id){
        orangService.updateOrang(id, orangInfo);
        return "redirect:/orang";
    }

    @PostMapping( value="/orang/submit/{id}", params={"delete"})
    public String orangDelete(@PathVariable("id") int id){
        orangService.deleteOrang(id);
        return "redirect:/orang";
    }

    // DetailPemesanan

    @GetMapping(value={"/detail", "/detail/"})
    public String DetailPage(Model model) {
        List<detailPemesanan> detailList = detailPemesananService.getAllDetailPemesanan();
        model.addAttribute("detailList", detailList);
        model.addAttribute("detailInfo", new detailPemesanan());
        return "detail.html";
    }

    @GetMapping("/detail/{id}")
    public String detailGetRec(Model model, @PathVariable("id") int id){
        List<detailPemesanan> detailList = detailPemesananService.getAllDetailPemesanan();
        detailPemesanan detailRec = detailPemesananService.getDetailPemesananById(id);
        model.addAttribute("detailList", detailList);
        model.addAttribute("detailRec", detailRec);
        return "detail.html";
    }

    @PostMapping( value={"/detail/submit/", "/detail/submit/{id}"}, params={"add"})
    public String detailAdd(@ModelAttribute("orangInfo") detailPemesanan detailInfo){
        detailPemesananService.addDetailPemesanan(detailInfo);
        return "redirect:/detail";
    }

    @PostMapping( value="/detail/submit/{id}", params={"edit"})
    public String detailEdit(@ModelAttribute("detailInfo") detailPemesanan detailInfo,
    @PathVariable("id") int id){
        detailPemesananService.updateDetailPemesanan(id, detailInfo);
        return "redirect:/detail";
    }

    @PostMapping( value="/detail/submit/{id}", params={"delete"})
    public String detailDelete(@PathVariable("id") int id){
        detailPemesananService.deleteDetailPemesanan(id);
        return "redirect:/detail";
    }

    // Pelanggan

    @GetMapping(value="/login")
    public String pelangganLoginPage(Model model, HttpServletRequest request) {
    if(request.getSession().getAttribute("Pelanggan") != null){
        return "redirect:/pelanggan";
    }
        else return "loginpelanggan";
    }

    @PostMapping(value="/validateLogin")
    public String pelangganLogin(Model model, @RequestParam(value="AccountID") Integer kodeUser,
    @RequestParam(value="noTelp") String passUser, HttpServletRequest request) {
        Pelanggan P = pelangganService.findPelanggan(kodeUser);
        model.addAttribute("userRec", P);
            if(P != null && passUser.equals(P.getNoTelp())) {
            request.getSession().setAttribute("Pelanggan", P);
            model.addAttribute("userRec", P);
            return "redirect:/pelanggan";
        }
        else return "redirect:/login";
    }

    @GetMapping(value="/pelangganlogout")
    public String pelangganlogout(HttpServletRequest request) {
    if (request.getSession().getAttribute("Pelanggan") != null) {
        request.getSession().invalidate();
    }
        return "redirect:/login";
    }

    @GetMapping(value={"/pelanggan", "/pelanggan/"})
    public String PelangganPage(Model model, HttpServletRequest request) {
        if(request.getSession().getAttribute("Pelanggan") != null){
            List<Pelanggan> pelangganList = pelangganService.getAllPelanggan();
            model.addAttribute("pelangganList", pelangganList);
            model.addAttribute("pelangganInfo", new Pelanggan());
            model.addAttribute("logPelanggan", request.getSession().getAttribute("Pelanggan"));
            return "pelanggan.html";
        }
        else return "redirect:/login";
    }

    @GetMapping("/pelanggan/{id}")
    public String pelangganGetRec(Model model, @PathVariable("id") int id){
        List<Pelanggan> pelangganList = pelangganService.getAllPelanggan();
        Pelanggan pelangganRec = pelangganService.getPelangganById(id);
        model.addAttribute("pelangganList", pelangganList);
        model.addAttribute("pelangganRec", pelangganRec);
        return "pelanggan.html";
    }

    @PostMapping( value={"/pelanggan/submit/", "/pelanggan/submit/{id}"}, params={"add"})
    public String pelangganAdd(@ModelAttribute("pelangganInfo") Pelanggan pelangganInfo){
        pelangganService.addPelanggan(pelangganInfo);
        return "redirect:/pelanggan";
    }

    @PostMapping( value="/pelanggan/submit/{id}", params={"edit"})
    public String pelangganEdit(@ModelAttribute("pelangganInfo") Pelanggan pelangganInfo,
    @PathVariable("id") int id){
        pelangganService.updatePelanggan(id, pelangganInfo);
        return "redirect:/pelanggan";
    }

    @PostMapping( value="/pelanggan/submit/{id}", params={"delete"})
    public String pelangganDelete(@PathVariable("id") int id){
        pelangganService.deletePelanggan(id);
        return "redirect:/pelanggan";
    }

    // Barang

    @GetMapping(value={"/barang", "/barang/"})
    public String BarangPage(Model model) {
        List<Barang> barangList = barangService.getAllBarang();
        model.addAttribute("barangList", barangList);
        model.addAttribute("barangInfo", new Barang());
        return "barang.html";
    }

    @GetMapping("/barang/{id}")
    public String barangGetRec(Model model, @PathVariable("id") long id){
    List<Barang> barangList = barangService.getAllBarang();
    Barang barangRec = barangService.getBarangById(id);
    model.addAttribute("barangList", barangList);
    model.addAttribute("barangRec", barangRec);
    return "barang.html";
    }

    @PostMapping( value={"/barang/submit/", "/barang/submit/{id}"}, params={"add"})
    public String barangAdd(@ModelAttribute("barangInfo") Barang barangInfo){
        barangService.addBarang(barangInfo);
        return "redirect:/barang";
    }

    @PostMapping( value="/barang/submit/{id}", params={"edit"})
    public String barangEdit(@ModelAttribute("barangInfo") Barang barangInfo,
    @PathVariable("id") int id){
        barangService.updateBarang(id, barangInfo);
        return "redirect:/barang";
    }

    @PostMapping( value="/barang/submit/{id}", params={"delete"})
    public String barangDelete(@PathVariable("id") long id){
        barangService.deleteBarang(id);
        return "redirect:/barang";
    }

    // Pengiriman

    @GetMapping(value={"/pengiriman", "/pengiriman/"})
    public String PengirimanPage(Model model) {
        List<Pengiriman> pengirimanList = pengirimanService.getAllPengiriman();
        model.addAttribute("pengirimanList", pengirimanList);
        model.addAttribute("pengirimanInfo", new Pengiriman());
        return "pengiriman.html";
    }

    @GetMapping("/pengiriman/{id}")
    public String pengirimanGetRec(Model model, @PathVariable("id") long id){
        List<Pengiriman> pengirimanList = pengirimanService.getAllPengiriman();
        Pengiriman pengirimanRec = pengirimanService.getPengirimanById(id);
        model.addAttribute("pengirimanList", pengirimanList);
        model.addAttribute("pengirimanRec", pengirimanRec);
        return "pengiriman.html";
    }

    @PostMapping( value={"/pengiriman/submit/", "/pengiriman/submit/{id}"}, params={"add"})
    public String pengirimanAdd(@ModelAttribute("pengirimanInfo") Pengiriman pengirimanInfo){
        pengirimanService.addPengiriman(pengirimanInfo);
        return "redirect:/pengiriman";
    }

    @PostMapping( value="/pengiriman/submit/{id}", params={"edit"})
    public String pengirimanEdit(@ModelAttribute("pengirimanInfo") Pengiriman pengirimanInfo,
    @PathVariable("id") long id){
        pengirimanService.updatePengiriman(id, pengirimanInfo);
        return "redirect:/pengiriman";
    }

    @PostMapping( value="/pengiriman/submit/{id}", params={"delete"})
    public String pengirimanDelete(@PathVariable("id") int id){
        pengirimanService.deletePengiriman(id);
        return "redirect:/pengiriman";
    }

}