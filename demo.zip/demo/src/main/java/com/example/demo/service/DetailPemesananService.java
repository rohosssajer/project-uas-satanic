package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.detailPemesanan;
import com.example.demo.repository.detailPemesananRepository;


@Service
public class DetailPemesananService {
    @Autowired
    private detailPemesananRepository detailPemesananRepository;

    public List<detailPemesanan> getAllDetailPemesanan() {
        return detailPemesananRepository.findAll();
    }

    public detailPemesanan addDetailPemesanan(detailPemesanan obj){
        obj.setPesananID(null);
        return detailPemesananRepository.save(obj);
    }

    public detailPemesanan getDetailPemesananById(long id){
        return detailPemesananRepository.findById(id).orElse(null);
    }

    public detailPemesanan updateDetailPemesanan(long id, detailPemesanan obj){
        return detailPemesananRepository.save(obj);
    }

    public void deleteDetailPemesanan(long id){
        detailPemesananRepository.deleteById(id);
    }
}