package com.example.demo.entity;

import jakarta.persistence.Entity;

@Entity
public class Pengiriman extends detailPemesanan{

    private String jenisKendaraan, noPemesanan, alamatTujuan;

    public Pengiriman() {}

    public Pengiriman(String catatan, String jenisKendaraan, String noPemesanan, String alamatTujuan) {
        super(catatan);
        this.jenisKendaraan = jenisKendaraan;
        this.noPemesanan = noPemesanan;
        this.alamatTujuan = alamatTujuan;
    }

    public void setJenisKendaraan(String jenisKendaraan) {
        this.jenisKendaraan = jenisKendaraan;
    }
    public String getJenisKendaraan() {
        return jenisKendaraan;
    }
    
    public void setNoPemesanan(String noPemesanan) {
        this.noPemesanan = noPemesanan;
    }
    public String getNoPemesanan() {
        return noPemesanan;
    }

    public void setAlamatTujuan(String alamatTujuan) {
        this.alamatTujuan = alamatTujuan;
    }
    public String getAlamatTujuan() {
        return alamatTujuan;
    }
}