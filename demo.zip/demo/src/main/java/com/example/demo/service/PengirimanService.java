package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Pengiriman;
import com.example.demo.repository.PengirimanRepository;

@Service
public class PengirimanService {

    @Autowired
    private PengirimanRepository pengirimanRepository;

    public List<Pengiriman> getAllPengiriman() { 
        return pengirimanRepository.findAll(); 
    }

    public Pengiriman addPengiriman(Pengiriman obj){
        obj.setPesananID(null);
        return pengirimanRepository.save(obj);
    }

    public Pengiriman getPengirimanById(long id) { 
        return pengirimanRepository.findById(id).orElse(null); 
    }

    public Pengiriman updatePengiriman(long id, Pengiriman obj){
        return pengirimanRepository.save(obj);
    }

    public void savePengiriman(Pengiriman pengiriman) { 
        pengirimanRepository.save(pengiriman); 
    }

    public void deletePengiriman(long id) { 
        pengirimanRepository.deleteById(id); 
    }
}