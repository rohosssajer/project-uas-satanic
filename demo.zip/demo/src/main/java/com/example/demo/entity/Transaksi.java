package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Transaksi {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idTransaksi;

    private double totalOngkos;

    private String metodePembayaran;

    public Transaksi() {}

    public Transaksi (Integer idTransaksi, double totalOngkos, String metodePembayaran) {
        this.idTransaksi = idTransaksi;
        this.totalOngkos = totalOngkos;
        this.metodePembayaran = metodePembayaran;
    }

    public void setIdTransaksi(Integer idTransaksi) {
        this.idTransaksi = idTransaksi;
    }
    public Integer getIdTransaksi() {
        return idTransaksi;
    }

    public void setTotalOngkos(double totalOngkos) {
        this.totalOngkos = totalOngkos;
    }
    public double getTotalOngkos() {
        return totalOngkos;
    }

    public void setMetodePembayaran(String metodePembayaran) {
        this.metodePembayaran = metodePembayaran;
    }
    public String getMetodePembayaran() {
        return metodePembayaran;
    }
}