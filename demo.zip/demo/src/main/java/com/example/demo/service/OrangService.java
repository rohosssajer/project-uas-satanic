package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Orang;
import com.example.demo.repository.OrangRepository;


@Service
public class OrangService {
    @Autowired
    private OrangRepository orangRepository;

    public List<Orang> getAllOrang() {
        return orangRepository.findAll();
    }

    public Orang addOrang(Orang obj){
        obj.setAccountID(null);
        return orangRepository.save(obj);
    }

    public Orang getOrangById(long id){
        return orangRepository.findById(id).orElse(null);
    }

    public Orang updateOrang(long id, Orang obj){
        return orangRepository.save(obj);
    }

    public void deleteOrang(long id){
        orangRepository.deleteById(id);
    }
}